
# TitleTesterPro

🚀 Production-ready application.

## Features
✅ Clean, premium dashboard UI.  
✅ Title rotation scheduler.  
✅ Stripe integration.  
✅ Views-only metrics (no CTR/Impressions).  
✅ Rotation logs.

## Folder Structure
src/
  components/Dashboard.tsx
  lib/scheduler.ts
  services/stripe-payment-integration.js
  services/test-analytics-api.ts

## Deployment
1️⃣ `npm install`  
2️⃣ Set environment vars: STRIPE_SECRET_KEY + BASE_URL  
3️⃣ Import and start scheduler in your main app:  
```tsx
import { startScheduler } from './src/lib/scheduler';
startScheduler();
```
4️⃣ `npm run dev`  
5️⃣ Test end-to-end flows.
